<!DOCTYPE html>
<html>
<head>
<title> hello</title>
</head>
<body>
<a href="thanjavur.php">hello</a>
<?php 
echo "Hi";
?>
</body>
</html>